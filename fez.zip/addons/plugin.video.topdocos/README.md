Top Documentary Films Plugin for Kodi
-------------------------------------------
Watch Top Documentary Films on Kodi. 

Setup/Installation: 
The plugin should be installed through the official Kodi addon repository.

Contact:
dtoumbourou@gmail.com

Top Documentary Films:
The world's greatest free documentary library - a place where documentaries are regarded as the supreme form of expression.

plugin.video.hallmark
================

Kodi Addon for Hallmark Channel website

Version 3.0.6 website change
Version 3.0.5 website change
Version 3.0.4 website change
Version 3.0.3 fixed movies and metadata
Version 3.0.2 Added 'Add to Library'
Version 3.0.1 Isengard - separate scraper
Version 1.0.1 initial release


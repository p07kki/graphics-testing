plugin.video.foodnetwork.canada
================

Kodi Addon for Food Network Canada website

Version 3.0.3 website changes
Version 3.0.2 website changes
Version 3.0.1 separate scraper for future services

plugin.video.wral
=====================
Kodi Addon for WCBS Programs website

icon.png sourced from public domain : 
https://commons.wikimedia.org/wiki/File:CBS_classic_logo.svg

fanart.jpg sourced from public domain:
https://commons.wikimedia.org/wiki/File:CBS_classic_logo.svg (converted to .jpg)

Change Log
=====================
V3.0.8 website change
V3.0.7 fix for subtitle format
V3.0.6 fix for dynamic metadata
V3.0.5 Added M3U8 support for "new" videos
V3.0.4 Added 'Add to Library'
V3.0.3 more cleanup
V3.0.2 fix for more than 100 shows; add evening news
V3.0.1 Separate scraper for future functions
V2.0.1 Initial version
plugin.video.rt
================
Kodi Addon for Russia Today News

3.0.2 added Spanish and Arab live feeds that I forgot
3.0.1 clean up and fix live feeds
2.0.2 website chnages
2.0.1 Isengard version - fixed live streams

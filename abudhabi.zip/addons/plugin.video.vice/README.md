Vice Plugin for Kodi
------------------------------------
Watch videos from Vice.

Setup/Installation: The plugin should be installed through the official Kodi repository.

Contact: dtoumbourou@gmail.com

-------------------------------------
Vice is an ever-expanding nebula of immersive investigative journalism, uncomfortable sociological examination, uncouth activities, making fun of people ...
 

Crackler
========

A no-frills Kodi/XBMC plugin for Crackle!

Installation Instructions:

Download the latest stable release of the plugin zip file at https://github.com/eignxing/Crackler/releases

In XBMC navigate to System->Settings and click "Add-ons."

Select "Install from zip file" and choose the zip file you just downloaded.

When the add-on is installed, it will be available in Videos->Add-ons as "Crackler."

Enjoy!


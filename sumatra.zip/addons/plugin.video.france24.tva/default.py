'''
    France 24 Live Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys,re,os,urllib,urllib2
from urllib2 import urlopen
import xbmc,xbmcgui,xbmcplugin,xbmcaddon

dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
addon_logo = xbmc.translatePath(os.path.join(plugin_path,'tvaddons_logo.png'))
fr24_fr_url = "http://www.france24.com/fr/tv-en-direct-chaine-live"
fr24_en_url = "http://www.france24.com/en/livefeed"
fr24_esp_url = "http://www.france24.com/es/tv-en-vivo-live"
fr24_ar_url = "http://www.france24.com/ar/livefeed"
channel_id_match_string = '<div class="yt-live-container"><iframe src="(.+?)&'
video_match_string = '\'VIDEO_ID\': "(.+?)"'

def find_single_match(text,pattern):
    result = ""
    try:    
        matches = re.findall(pattern,text,flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""
    return result

def get_playable_url(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url

if __name__ == '__main__':
    #TVADDONS Branding
    xbmcgui.Dialog().notification(addon_name + ' is provided by:','www.tvaddons.co',addon_logo,10000,False)

    #Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
    yt_addon = xbmcaddon.Addon('plugin.video.youtube')
    if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
        dlg.ok(addon_name, "This addon requires MPEG-DASH to be enabled in the YouTube addon. Once enabled try again.")
        yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
        xbmc.executebuiltin('yt_settings')
        xbmc.executebuiltin('Activatewindow(home)')
    else: 
        #Channel Selection
        source = dlg.select("Choose Channel", [
            "[COLOR blue]French[/COLOR]",
            "[COLOR blue]English[/COLOR]",
            "[COLOR blue]Spanish[/COLOR]",
            "[COLOR blue]Arabic[/COLOR]"])
        if source == 0:
            channel_url = fr24_fr_url
        if source == 1:
            channel_url = fr24_en_url
        if source == 2:
            channel_url = fr24_esp_url
        if source == 3:
            channel_url = fr24_ar_url
        if source < 0:
            xbmc.executebuiltin('Activatewindow(home)')
            exit()

        #Get France 24 YouTube Channel
        req = urllib2.Request(channel_url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        channel = find_single_match(link,channel_id_match_string)

        #Get Stream
        req = urllib2.Request(channel)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        id = find_single_match(link,video_match_string)
        if id is not "":
            stream = get_playable_url(id)
            xbmc.Player().play(stream)
            xbmc.executebuiltin('Activatewindow(home)')
        else:
            dlg.ok(addon_name, "Unable to get stream. Please try again later.")
            xbmc.executebuiltin('Activatewindow(home)')

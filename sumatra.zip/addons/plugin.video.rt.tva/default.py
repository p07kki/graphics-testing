'''
    RT News Live Add-on

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys,re,os,urllib,urllib2
from urllib2 import urlopen
import xbmc,xbmcgui,xbmcplugin,xbmcaddon

dlg = xbmcgui.Dialog()
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')
plugin_path = xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
addon_logo = xbmc.translatePath(os.path.join(plugin_path,'tvaddons_logo.png'))
rt_url = "https://www.rt.com/on-air/"
rtus_url = "https://www.rt.com/on-air/rt-america-air/"
rtuk_url = "https://www.rt.com/on-air/rt-uk-air/"
rtfr_url = "https://francais.rt.com/en-direct"
rtar_url = "https://arabic.rt.com/live/"
rtesp_url = "https://actualidad.rt.com/en_vivo"
rtdoc_url = "https://rtd.rt.com/on-air/"
stream_id_match_string = "file: '(.+?)'"
stream_france_id_match_string = 'file: "(.+?)"'
stream_arabic_id_match_string = "file': '(.+?)'"
stream_spanish_id_match_string = "embed/(.+?)\?"
stream_doc_id_match_string = 'url: "(.+?)"'

def find_single_match(text,pattern):
    result = ""
    try:    
        matches = re.findall(pattern,text,flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""
    return result

def get_playable_url(id):
    url = 'plugin://plugin.video.youtube/play/?video_id=%s' % id
    return url

if __name__ == '__main__':
    #TVADDONS Branding
    dlg.notification(addon_name + ' is provided by:','www.tvaddons.co',addon_logo,10000,False)

    #Ensure YouTube addon MPEG-DASH setting is enabled and if not prompt user to set it
    yt_addon = xbmcaddon.Addon('plugin.video.youtube')
    if yt_addon.getSetting('kodion.video.quality.mpd') != 'true':
        dlg.ok(addon_name, "This addon requires MPEG-DASH to be enabled in the YouTube addon. Once enabled try again.")
        yt_settings = xbmcaddon.Addon('plugin.video.youtube').openSettings()
        xbmc.executebuiltin('yt_settings')
        xbmc.executebuiltin('Activatewindow(home)')
    else:
        #Channel Selection
        source = xbmcgui.Dialog().select("Choose Channel", ["[COLOR blue]RT Global[/COLOR]","[COLOR blue]RT America[/COLOR]","[COLOR blue]RT UK[/COLOR]","[COLOR blue]RT France[/COLOR]","[COLOR blue]RT Arabic[/COLOR]","[COLOR blue]RT Spanish[/COLOR]","[COLOR blue]RT Documentary[/COLOR]"])
        if source == 0:
            channel_url = rt_url
            match_string = stream_id_match_string
            vid_name = "RT Global"
        if source == 1:
            channel_url = rtus_url
            match_string = stream_id_match_string
            vid_name = "RT America"
        if source == 2:
            channel_url = rtuk_url
            match_string = stream_id_match_string
            vid_name = "RT UK"
        if source == 3:
            channel_url = rtfr_url
            match_string = stream_france_id_match_string
            vid_name = "RT France"
        if source == 4:
            channel_url = rtar_url
            match_string = stream_arabic_id_match_string
            vid_name = "RT Arabic"
        if source == 5:
            channel_url = rtesp_url
            match_string = stream_spanish_id_match_string
        if source == 6:
            channel_url = rtdoc_url
            match_string = stream_doc_id_match_string
            vid_name = "RT Documentary"
        if source < 0:
            xbmc.executebuiltin('Activatewindow(home)')
            exit()

        #Get RT stream depending on Channel Selection
        req = urllib2.Request(channel_url)
        req.add_header('User-Agent','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link = response.read()
        response.close()
        #Use YouTube for RT Spanish Streams
        if source == 5:
            id = find_single_match(link,match_string)
            if id is not "":
                stream = get_playable_url(id)
                xbmc.Player().play(stream)
                xbmc.executebuiltin('Activatewindow(home)')
            else:
                dlg.ok(addon_name, "Unable to get stream. Please try again later.")
                xbmc.executebuiltin('Activatewindow(home)')
        #Stream direct for streams other than RT Spanish
        else:
            stream = find_single_match(link,match_string)
            if "m3u8" in stream:
                li = xbmcgui.ListItem(vid_name)
                xbmc.Player().play(stream,li,False)
                xbmc.executebuiltin('Activatewindow(home)')
            else:
                dlg.ok(addon_name, "Unable to get stream. Please try again later.")
                xbmc.executebuiltin('Activatewindow(home)')

plugin.video.cbcnews
================

Kodi Video Addon for CBC News - for use in Canada only
For Kodi Isengard and later releases

V3.0.1 Initial version CBC News
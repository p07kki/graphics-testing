Version 3.0.10 website change
Version 3.0.9 bump t1mlib version to fix timeout request on Kodi 17.0 Android
Version 3.0.8 Fix crap in metadata
Version 3.0.7 Website changes
Version 3.0.6 Website changes
Version 3.0.4 Website changes
Version 3.0.3 Change to changelog.txt
Version 3.0.2 Improve episode scraping
Version 3.0.1 Isengard version
Version 1.0.4 website change
Version 1.0.3 website change
Version 1.0.1 Initial release

